# Build an Alexa Smart Home Skill and Backend
These instructions build a Sample Alexa Smart Home skill and backend using Cloud Formation using the Amazon API Gateway as an access layer to AWS IoT Things that represent the state of customer endpoints.


To begin, start with [Step 0: Set Up the Required Accounts](docs/000-setup-requirements.md) 

